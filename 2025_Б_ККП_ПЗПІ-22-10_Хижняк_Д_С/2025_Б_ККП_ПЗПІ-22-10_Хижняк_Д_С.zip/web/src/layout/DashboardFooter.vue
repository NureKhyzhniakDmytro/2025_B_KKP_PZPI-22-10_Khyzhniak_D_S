<template>
  <footer
      class="w-full shadow p-4 text-center text-color bg-surface-0"
  >
    &copy; 2025 AirSense
  </footer>
</template>

<script setup lang="ts"></script>