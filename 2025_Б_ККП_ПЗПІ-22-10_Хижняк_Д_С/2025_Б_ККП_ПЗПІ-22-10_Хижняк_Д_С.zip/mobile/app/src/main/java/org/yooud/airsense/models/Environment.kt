package org.yooud.airsense.models

data class Environment(val id: Int, val name: String, val role: String)
