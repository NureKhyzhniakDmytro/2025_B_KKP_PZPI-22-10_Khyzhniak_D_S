package org.yooud.airsense.auth

object SessionManager {
    var token: String? = null
}