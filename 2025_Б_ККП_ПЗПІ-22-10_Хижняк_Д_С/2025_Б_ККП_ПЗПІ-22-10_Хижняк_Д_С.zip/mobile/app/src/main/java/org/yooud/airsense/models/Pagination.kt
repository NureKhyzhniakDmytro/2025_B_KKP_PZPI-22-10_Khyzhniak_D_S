package org.yooud.airsense.models

data class Pagination(val total: Int, val skip: Int, val count: Int)
