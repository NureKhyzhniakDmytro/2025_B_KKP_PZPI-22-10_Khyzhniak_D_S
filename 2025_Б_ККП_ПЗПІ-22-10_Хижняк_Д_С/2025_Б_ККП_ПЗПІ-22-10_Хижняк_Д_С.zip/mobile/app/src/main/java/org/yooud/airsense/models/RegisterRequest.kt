package org.yooud.airsense.models

data class RegisterRequest(val notificationToken: String)
