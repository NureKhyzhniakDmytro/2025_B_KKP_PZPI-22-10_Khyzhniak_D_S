namespace Airsense.API.Models.Dto.Environment;

public class EnvironmentMemberDto
{
    public int Id { get; set; }
    
    public string Name { get; set; }

    public string Email { get; set; }
    
    public string Role { get; set; }
}