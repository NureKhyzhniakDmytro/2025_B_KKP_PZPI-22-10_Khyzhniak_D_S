namespace Airsense.API.Models.Dto.Room;

public class HistoryDeviceDataDto
{
    public double Value { get; set; }
    
    public long Timestamp { get; set; }
}