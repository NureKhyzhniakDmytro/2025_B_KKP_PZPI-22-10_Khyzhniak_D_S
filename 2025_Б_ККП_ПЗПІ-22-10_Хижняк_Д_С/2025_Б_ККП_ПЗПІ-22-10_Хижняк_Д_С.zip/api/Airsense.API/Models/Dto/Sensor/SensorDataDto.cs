namespace Airsense.API.Models.Dto.Sensor;

public class SensorDataDto
{
    public double Value { get; set; }

    public long SentAt { get; set; }
}