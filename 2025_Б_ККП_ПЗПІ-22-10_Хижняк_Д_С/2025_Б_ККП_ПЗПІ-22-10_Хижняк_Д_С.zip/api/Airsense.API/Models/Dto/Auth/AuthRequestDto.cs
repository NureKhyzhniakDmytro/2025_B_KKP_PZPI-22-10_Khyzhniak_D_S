namespace Airsense.API.Models.Dto.Auth;

public class AuthRequestDto
{
    public string? NotificationToken { get; set; }
}