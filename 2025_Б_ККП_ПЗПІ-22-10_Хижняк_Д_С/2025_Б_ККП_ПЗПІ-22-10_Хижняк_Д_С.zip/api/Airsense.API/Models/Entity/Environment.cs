namespace Airsense.API.Models.Entity;

public class Environment
{
    public int Id { get; set; }
    
    public string Name { get; set; }
}