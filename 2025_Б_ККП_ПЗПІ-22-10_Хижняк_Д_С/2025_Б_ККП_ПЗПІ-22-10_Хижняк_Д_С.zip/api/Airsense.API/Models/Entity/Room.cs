namespace Airsense.API.Models.Entity;

public class Room
{
    public int Id { get; set; }

    public string Name { get; set; }

    public int EnvironmentId { get; set; }
}